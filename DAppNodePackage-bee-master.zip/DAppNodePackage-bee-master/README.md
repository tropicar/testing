# DAppNodePackage-bee

## **Ethereum Swarm Bee**
![avatar](swarm-avatar-min.png)

### What is Swarm?

Swarm is a decentralised storage and communication system for a sovereign digital society.

Swarm is a system of peer-to-peer networked nodes that create a decentralised storage and communication service.
The system is economically self-sustaining due to a built-in incentive system enforced through smart contracts on the Ethereum blockchain.

### How does it work?

Bee is a Swarm client implemented in Go. It’s the basic building block for the Swarm network.

You can get more information about the project on his official site https://swarm.ethereum.org/

